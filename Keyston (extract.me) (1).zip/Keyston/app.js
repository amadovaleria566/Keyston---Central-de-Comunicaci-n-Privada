document.addEventListener('DOMContentLoaded', init);

const currentPage = window.location.pathname.split('/').pop();
if (!localStorage.getItem('keyston_login') && currentPage === 'index.html') {
  // window.location.href = 'login.html'; 
}

const SELECTORS = {
  postsContainer: '#posts-container',
  quickFilter: '#quick-filter',
  viewSelect: '#view-select',
  composeBtn: '#compose-btn',
  composeModal: '#compose-modal',
  composeClose: '#compose-close',
  composeForm: '#compose-form',
  composeCancel: '#compose-cancel',
  themeToggle: '#theme-toggle',
  splash: '#splash',
  searchBar: '#search-bar',
  searchInput: '#search-input',
  sortSelect: '#sort-select',
  contactForm: '#contact-form',
  toasts: '#toasts',
  commentDrawer: '#comment-drawer',
  drawerContent: '#drawer-content',
  drawerClose: '#drawer-close',
  openSearch: '#open-search',
  clearSearch: '#clear-search',
  viewGridClass: 'grid',
  authBtn: '#auth-btn', 
  loginForm: '#login-form', 
  registerForm: '#register-form' 
};

let POSTS = [];
let filteredPosts = [];
let reactions = {}; 
let comments = {};  
let theme = 'light';

async function init(){
  showSplash();
  loadTheme();
  bindUI();
  
  if (currentPage === 'index.html'){
    await loadPosts();
    applyFilters();
  }
  
  if (currentPage === 'login.html') {
    bindLoginUI();
  } else if (currentPage === 'register.html') {
    bindRegisterUI();
  }

  hideSplash();
  if (currentPage === 'index.html' || currentPage === 'contacto.html') {
    applyAnimations();
    setupIntersectionObserver();
  }
}

function showSplash(){
  const s = document.querySelector(SELECTORS.splash);
  if (s) s.style.display = 'flex';
}
function hideSplash(){
  const s = document.querySelector(SELECTORS.splash);
  if (s) s.style.display = 'none';
}

function loadTheme(){
  const saved = localStorage.getItem('keyston_theme');
  theme = saved || (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  updateTheme();
  document.querySelector(SELECTORS.themeToggle).addEventListener('click', toggleTheme);
}
function toggleTheme(){
  theme = theme === 'dark' ? 'light' : 'dark';
  localStorage.setItem('keyston_theme', theme);
  updateTheme();
  showToast(`Tema cambiado a ${theme === 'dark' ? 'oscuro' : 'claro'}`);
}
function updateTheme(){
  if (theme === 'dark') document.documentElement.classList.add('dark');
  else document.documentElement.classList.remove('dark');
  const ico = document.querySelector(`${SELECTORS.themeToggle} i`);
  if (ico) ico.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

function bindUI(){
  if (currentPage === 'index.html') {
    document.querySelector(SELECTORS.quickFilter).addEventListener('input', debounce(onFilter, 220));
    document.querySelector(SELECTORS.sortSelect).addEventListener('change', applyFilters);
    document.querySelector(SELECTORS.composeBtn).addEventListener('click', openCompose);
    document.getElementById('compose-close').addEventListener('click', closeCompose);
    document.getElementById('compose-cancel').addEventListener('click', closeCompose);
    document.getElementById('compose-form').addEventListener('submit', handleCompose);
    document.getElementById('drawer-close').addEventListener('click', closeDrawer);
  }

  const contactForm = document.querySelector(SELECTORS.contactForm);
  if (contactForm && currentPage === 'contacto.html'){
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!validateContactForm()) return;
      showToast('¡Gracias! Tu mensaje ha sido enviado (simulado).');
      contactForm.reset();
    });
  }

  const authBtn = document.querySelector(SELECTORS.authBtn);
  if (authBtn) {
    updateAuthButton(authBtn);
    authBtn.addEventListener('click', handleAuthAction);
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (currentPage === 'index.html') {
        closeCompose();
        closeDrawer();
      }
    }
  });
}

function updateAuthButton(btn) {
  const isLoggedIn = localStorage.getItem('keyston_login');
  if (isLoggedIn) {
    btn.textContent = 'Cerrar Sesión';
    btn.dataset.action = 'logout';
    btn.href = '#';
  } else {
    btn.textContent = 'Área Privada';
    btn.dataset.action = 'login';
    btn.href = 'login.html';
  }
}

function handleAuthAction(e) {
  const action = e.currentTarget.dataset.action;
  if (action === 'logout') {
    e.preventDefault();
    if (confirm('¿Estás seguro de que quieres cerrar sesión?')) {
      localStorage.removeItem('keyston_login');
      showToast('Sesión cerrada');
      window.location.href = 'login.html'; 
    }
  } else if (action === 'login') {
  }
}

function bindLoginUI() {
  const loginForm = document.querySelector(SELECTORS.loginForm);
  if (!loginForm) return;

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const user = document.getElementById('user').value;
    const pass = document.getElementById('password').value;
    
    const users = JSON.parse(localStorage.getItem('keyston_users') || '[]');
    const userFound = users.find(u => u.user === user && u.pass === pass);

    if (userFound) {
      localStorage.setItem('keyston_login', userFound.user);
      showToast('¡Bienvenido! Iniciando sesión...');
      window.location.href = 'index.html'; 
    } else {
      showToast('Usuario o contraseña incorrectos.', true);
    }
  });
}

function bindRegisterUI() {
  const registerForm = document.querySelector(SELECTORS.registerForm);
  if (!registerForm) return;

  registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const user = document.getElementById('user-reg').value.trim();
    const pass = document.getElementById('password-reg').value.trim();
    
    if (user.length < 3 || pass.length < 6) {
      showToast('El usuario debe tener min. 3 caracteres y la contraseña min. 6.', true);
      return;
    }

    let users = JSON.parse(localStorage.getItem('keyston_users') || '[]');
    if (users.some(u => u.user === user)) {
      showToast('Ese nombre de usuario ya está en uso.', true);
      return;
    }

    const newUser = { user, pass };
    users.push(newUser);
    localStorage.setItem('keyston_users', JSON.stringify(users));
    
    showToast('¡Registro exitoso! Por favor inicia sesión.');
    registerForm.reset();
    window.location.href = 'login.html'; 
  });
}

async function loadPosts(){
  const saved = localStorage.getItem('keyston_posts');
  if (saved){
    POSTS = JSON.parse(saved);
  } else {
    try {
      const res = await fetch('data/posts.json');
      if (!res.ok) throw new Error('No se pudo cargar posts.');
      POSTS = await res.json();
      localStorage.setItem('keyston_posts', JSON.stringify(POSTS));
    } catch (err) {
      console.error(err);
      POSTS = []; 
      showToast('Error cargando publicaciones.');
    }
  }

  reactions = JSON.parse(localStorage.getItem('keyston_reactions') || '{}');
  comments = JSON.parse(localStorage.getItem('keyston_comments') || '{}');

  POSTS.forEach(p => {
    if (reactions[p.id] == null) reactions[p.id] = p.reactions || 0;
    if (!comments[p.id]) comments[p.id] = [];
  });

  localStorage.setItem('keyston_reactions', JSON.stringify(reactions));
  localStorage.setItem('keyston_comments', JSON.stringify(comments));

  filteredPosts = [...POSTS];
}

function renderPosts(){
  const container = document.querySelector(SELECTORS.postsContainer);
  if (!container) return;

  container.innerHTML = '';
  container.className = 'posts-grid';

  if (filteredPosts.length === 0) {
    document.getElementById('no-results').classList.remove('hidden');
  } else {
    document.getElementById('no-results').classList.add('hidden');
  }

  filteredPosts.forEach(post => {
    const card = document.createElement('article');
    card.className = 'post-card';
    card.dataset.id = post.id;
    card.innerHTML = `
      <div>
        <h3>${escapeHtml(post.title)}</h3>
        <div class="post-meta"><span class="badge">${escapeHtml(post.author)}</span> &nbsp;•&nbsp; ${escapeHtml(post.date)}</div>
        <p class="post-content">${truncate(escapeHtml(post.content), 280)}</p>
      </div>

      <div class="post-actions">
        <div style="display:flex;gap:8px;align-items:center">
          <button class="reaction-btn btn-small" data-id="${post.id}" aria-label="Reaccionar"><i class="fas fa-thumbs-up"></i> <span class="count">${reactions[post.id] || 0}</span></button>
          <button class="btn btn-small" data-comment="${post.id}" aria-label="Comentarios"><i class="fas fa-comments"></i> Comentarios (${(comments[post.id]||[]).length})</button>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="btn btn-ghost btn-small" data-id="${post.id}" data-action="read">Leer más</button>
          <button class="btn btn-ghost btn-small" data-action="share" data-id="${post.id}"><i class="fas fa-share"></i></button>
        </div>
      </div>
    `;

    const reactBtn = card.querySelector('.reaction-btn');
    reactBtn.addEventListener('click', handleReaction);

    const commentBtn = card.querySelector('button[data-comment]');
    commentBtn.addEventListener('click', openComments);

    const readBtn = card.querySelector('button[data-action="read"]');
    readBtn.addEventListener('click', () => openReadModal(post));

    const shareBtn = card.querySelector('button[data-action="share"]');
    shareBtn.addEventListener('click', () => handleShare(post));

    container.appendChild(card);
  });
}

function handleReaction(e){
  const id = e.currentTarget.dataset.id;
  const intId = String(id);
  reactions[intId] = (reactions[intId] || 0) + 1;
  localStorage.setItem('keyston_reactions', JSON.stringify(reactions));
  const countEl = e.currentTarget.querySelector('.count');
  if (countEl) countEl.textContent = reactions[intId];
  e.currentTarget.classList.add('liked');
  showToast('¡Reacción agregada!');
}

function openComments(e){
  const id = e.currentTarget.dataset.comment;
  const p = POSTS.find(x => String(x.id) === String(id));
  if (!p) return;
  const drawer = document.querySelector(SELECTORS.commentDrawer);
  const content = document.querySelector(SELECTORS.drawerContent);
  content.innerHTML = `
    <h3>${escapeHtml(p.title)}</h3>
    <p class="post-meta">Por ${escapeHtml(p.author)} • ${escapeHtml(p.date)}</p>
    <div style="margin:12px 0">${escapeHtml(p.content)}</div>
    <hr />
    <div id="comments-list"></div>
    <form id="comment-form" style="margin-top:12px">
      <input id="comment-author" placeholder="Tu nombre" required style="width:100%;padding:10px;border-radius:8px;margin-bottom:8px"/>
      <textarea id="comment-text" placeholder="Escribe un comentario..." required style="width:100%;padding:10px;border-radius:8px"></textarea>
      <div style="display:flex;gap:8px;margin-top:8px">
        <button class="btn btn-primary" type="submit">Comentar</button>
        <button type="button" id="clear-comments" class="btn btn-ghost">Borrar comentarios</button>
      </div>
    </form>
  `;
  populateComments(id);
  drawer.classList.remove('hidden');

  document.getElementById('comment-form').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const loggedUser = localStorage.getItem('keyston_login');
    const author = loggedUser || document.getElementById('comment-author').value.trim() || 'Anónimo';
    const text = document.getElementById('comment-text').value.trim();
    if (!text) return;
    const item = { author, text, date: (new Date()).toLocaleString() };
    comments[id] = comments[id] || [];
    comments[id].unshift(item);
    localStorage.setItem('keyston_comments', JSON.stringify(comments));
    populateComments(id);
    document.getElementById('comment-form').reset();
    showToast('Comentario publicado');
    const commentBtn = document.querySelector(`button[data-comment="${id}"]`);
    if (commentBtn) {
        commentBtn.innerHTML = `<i class="fas fa-comments"></i> Comentarios (${(comments[id]||[]).length})`;
    }
  });

  document.getElementById('clear-comments').addEventListener('click', () => {
    if (!confirm('¿Eliminar todos los comentarios de esta publicación?')) return;
    comments[id] = [];
    localStorage.setItem('keyston_comments', JSON.stringify(comments));
    populateComments(id);
    showToast('Comentarios borrados');
    const commentBtn = document.querySelector(`button[data-comment="${id}"]`);
    if (commentBtn) {
        commentBtn.innerHTML = `<i class="fas fa-comments"></i> Comentarios (${(comments[id]||[]).length})`;
    }
  });
}

function populateComments(id){
  const list = document.getElementById('comments-list');
  list.innerHTML = '';
  const arr = comments[id] || [];
  if (arr.length === 0) {
    list.innerHTML = '<p class="muted">Aún no hay comentarios. ¡Sé el primero!</p>';
    return;
  }
  arr.forEach(c => {
    const div = document.createElement('div');
    div.style.padding = '8px 0';
    div.innerHTML = `<strong>${escapeHtml(c.author)}</strong> <span class="muted small">• ${escapeHtml(c.date)}</span><div style="margin-top:6px">${escapeHtml(c.text)}</div>`;
    list.appendChild(div);
  });
}

function closeDrawer(){ document.querySelector(SELECTORS.commentDrawer)?.classList.add('hidden') }

function openReadModal(post){
  const content = `${post.title}\n\nPor: ${post.author} • ${post.date}\n\n${post.content}`;
  showToast('Apertura de lectura (simulada).');
  console.info('Leer publicación:', content);
  alert(content);
}

function handleShare(post){
  const url = location.href.split('#')[0] + `#post-${post.id}`;
  if (navigator.share) {
    navigator.share({title:post.title,text:post.content,url}).then(()=>showToast('Compartido correctamente')).catch(()=>showToast('No se pudo compartir'));
  } else {
    navigator.clipboard?.writeText(url).then(()=>showToast('Enlace copiado al portapapeles'));
  }
}

function onFilter(e){
  applyFilters();
}

function clearSearch(){
  document.querySelector(SELECTORS.quickFilter).value = '';
  applyFilters();
  showToast('Búsqueda limpiada');
}

function applyFilters(){
  const q = (document.querySelector(SELECTORS.quickFilter)?.value || '').trim().toLowerCase();
  const s = document.querySelector(SELECTORS.sortSelect)?.value || 'newest';

  filteredPosts = POSTS.filter(p => {
    if (!q) return true;
    return (p.title + ' ' + p.content + ' ' + p.author).toLowerCase().includes(q);
  });

  if (s === 'newest') filteredPosts.sort((a,b)=>new Date(b.date) - new Date(a.date));
  if (s === 'oldest') filteredPosts.sort((a,b)=>new Date(a.date) - new Date(b.date));
  if (s === 'popular') filteredPosts.sort((a,b)=> (reactions[b.id]||0) - (reactions[a.id]||0));

  renderPosts();
}

function openCompose(){ 
  if (!localStorage.getItem('keyston_login')) {
    showToast('Debes iniciar sesión para crear publicaciones.', true);
    return;
  }
  document.querySelector(SELECTORS.composeModal).classList.remove('hidden'); 
  document.getElementById('post-title').focus(); 
}
function closeCompose(){ document.querySelector(SELECTORS.composeModal).classList.add('hidden'); }

function handleCompose(e){
  e.preventDefault();
  const title = document.getElementById('post-title').value.trim();
  const loggedUser = localStorage.getItem('keyston_login');
  const manualAuthor = document.getElementById('post-author').value.trim();
  const author = loggedUser || manualAuthor;
  const content = document.getElementById('post-content').value.trim();
  
  if (!title || !author || !content) {
    showToast('Completa todos los campos', true);
    return;
  }
  const newPost = {
    id: (Date.now()),
    title, author,
    date: (new Date()).toLocaleString('es-CO', {year:'numeric', month:'long', day:'numeric'}),
    content,
    reactions: 0
  };
  POSTS.unshift(newPost);
  localStorage.setItem('keyston_posts', JSON.stringify(POSTS));
  reactions[newPost.id] = 0;
  localStorage.setItem('keyston_reactions', JSON.stringify(reactions));
  comments[newPost.id] = [];
  localStorage.setItem('keyston_comments', JSON.stringify(comments));
  closeCompose();
  applyFilters();
  showToast('Publicación creada');
  document.getElementById('compose-form').reset();
}

function onViewChange(e){
  const v = e.target.value;
  if (v === 'grid') document.querySelector(SELECTORS.postsContainer).classList.remove('list');
  else document.querySelector(SELECTORS.postsContainer).classList.add('list');
}

function showToast(message, isError=false, timeout=2800){
  const container = document.querySelector(SELECTORS.toasts);
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'toast';
  el.style.background = isError ? '#b91c1c' : undefined;
  el.innerHTML = `<div style="flex:1">${escapeHtml(message)}</div><button class="icon-btn" aria-label="cerrar" style="color:white"><i class="fas fa-times"></i></button>`;
  el.querySelector('button').addEventListener('click', ()=> el.remove());
  container.appendChild(el);
  setTimeout(()=>{ el.remove(); }, timeout);
}

function escapeHtml(text){
  if (!text && text !== 0) return '';
  return String(text)
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'", '&#039;');
}

function truncate(text, len=220){
  return text.length > len ? text.slice(0,len) + '…' : text;
}

function debounce(fn, wait=200){
  let t;
  return function(...args){ clearTimeout(t); t = setTimeout(()=> fn.apply(this,args), wait); };
}

function setupIntersectionObserver(){
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(ent => {
      if (ent.isIntersecting) {
        ent.target.style.transform = 'translateY(0) scale(1)';
        ent.target.style.opacity = '1';
        observer.unobserve(ent.target);
      }
    });
  }, {threshold:0.12});

  document.querySelectorAll('.post-card').forEach(el => {
    el.style.transform = 'translateY(10px) scale(.995)';
    el.style.opacity = '0';
    observer.observe(el);
  });
}

function applyAnimations(){
  document.querySelectorAll('.content-section').forEach((el,i)=> {
    el.style.transition = 'opacity .45s ease';
    el.style.transitionDelay = (i*40)+'ms';
    el.style.opacity = '1';
  });
}

function validateContactForm(){
  let ok = true;
  const form = document.querySelector(SELECTORS.contactForm);
  const name = form.querySelector('#name');
  const email = form.querySelector('#email');
  const message = form.querySelector('#message');

  form.querySelectorAll('.field-error').forEach(e=>e.classList.add('hidden'));

  if (!name.value || name.value.trim().length < 2) {
    form.querySelector('#name').nextElementSibling.classList.remove('hidden');
    ok = false;
  }
  if (!email.value || !/^\S+@\S+\.\S+$/.test(email.value)) {
    form.querySelector('#email').nextElementSibling.classList.remove('hidden');
    ok = false;
  }
  if (!message.value || message.value.trim().length < 5) {
    form.querySelector('#message').nextElementSibling.classList.remove('hidden');
    ok = false;
  }
  if (!ok) showToast('Completa correctamente el formulario', true, 2600);
  return ok;
} 